import pygame.mixer

from parametry import *
from klasy import *
pygame.init()




def gra(level):     # wybor poziomu
    run = True
    player = Geralt()
    clock = 0
    przegrana = 0
    background = Background(level)
    pause = False
    pause_image = pygame.font.Font.render(pygame.font.SysFont("", 120), "PAUZA", True, (0, 0, 0))
    (beams, monety, ghoule, nilfgardczycy, wynik0) = parametry(level)
    pygame.mixer.music.play(-1)


    while run:      # petla gry
        wynik = wynik0 - len(monety)
        clock += pygame.time.Clock().tick(80) / 1000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pause = not pause

        if pause:       # pauza
            window.blit(pause_image, (500, 300))
            przycisk_wyjdz = Przycisk(530, 700, "przyciski/wyjdz")
            przycisk_graj = Przycisk(530, 600, "przyciski/graj")
            if przycisk_wyjdz.tick():
                run = False
            if przycisk_graj.tick():
                pause = not pause
            przycisk_wyjdz.draw(window)
            przycisk_graj.draw(window)
            pygame.display.update()
            continue

        keys = pygame.key.get_pressed()

        # aktualizacja polozenia elementow wzgledem tla
        background.tick(player)
        background.draw(window)
        (polozenie, przegrana) = player.tick(keys, beams, monety, ghoule, nilfgardczycy, background.width, przegrana)

        # wyswietla wynik
        wynik_image = pygame.font.Font.render(pygame.font.SysFont("arial", 50), f"Wynik: {wynik}", True, (0, 0, 0))

        for ghoul in ghoule:
            ghoul.tick()

        for nilfgardczyk in nilfgardczycy:
            # WARUNEK PRZEGRANEJ1
            if nilfgardczyk.tick(polozenie, beams) == 1:
                porazka()
                run = False

        # WARUNEK PRZEGRANEJ2
        if przegrana == 1:
            porazka()
            run = False

        # WARUNEK WYGRANEJ
        if wynik == wynik0:
            zwyciestwo()
            run = False

        # rysowanie
        window.blit(wynik_image, (0, 0))
        player.draw(window, background.width)

        for beam in beams:
            beam.draw(window, background.x_cord)

        for moneta in monety:
            moneta.draw(background.x_cord)

        for ghoul in ghoule:
            ghoul.draw(background.x_cord)

        for nilfgardczyk in nilfgardczycy:
            nilfgardczyk.draw(background.x_cord)
        pygame.display.update()



def main():     #glowna petla, menu gry
    run = True
    clock = 0
    tlo = pygame.image.load("background/menu.jpg")
    przycisk_wyjdz = Przycisk(530, 510, "przyciski/wyjdz")
    przycisk_poziom1 = Przycisk(530, 150, "przyciski/poziom1")
    przycisk_poziom2 = Przycisk(530, 270, "przyciski/poziom2")
    przycisk_poziom3 = Przycisk(530, 390, "przyciski/poziom3")
    pygame.mixer.music.load("soundtrack/menu.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.1)

    while run:      #glowna petla, menu gry

        clock += pygame.time.Clock().tick(60) / 1000
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        # sprawdzanie, czy przycisk zostal wcisniety
        if przycisk_poziom1.tick():
            gra(1)
            pygame.mixer.music.load("soundtrack/menu.mp3")
            pygame.mixer.music.play(-1)

        if przycisk_poziom2.tick():
            gra(2)
            pygame.mixer.music.load("soundtrack/menu.mp3")
            pygame.mixer.music.play(-1)

        if przycisk_poziom3.tick():
            gra(3)
            pygame.mixer.music.load("soundtrack/menu.mp3")
            pygame.mixer.music.play(-1)

        if przycisk_wyjdz.tick():
            run = False

        # rysowanie elementow i tla
        window.blit(tlo, (0, 0))
        prawa_autorskie_image = pygame.font.Font.render(pygame.font.SysFont("", 30), f"W grze wykorzystany został soundtrack z gry Wiedzmin 3 Dziki Gon", True, (242, 245, 247))
        window.blit(prawa_autorskie_image, (280, 750))
        sterowanie_image = pygame.font.Font.render(pygame.font.SysFont("", 30), "A/D - RUCH,   SPACJA - SKOK,   PRAWY CTRL - ATAK,   ESC - PAUZA", True, (242, 245, 247))
        window.blit(sterowanie_image, (320, 40))
        przycisk_poziom1.draw(window)
        przycisk_poziom2.draw(window)
        przycisk_poziom3.draw(window)
        przycisk_wyjdz.draw(window)
        pygame.display.update()


if __name__ == "__main__":
    main()
