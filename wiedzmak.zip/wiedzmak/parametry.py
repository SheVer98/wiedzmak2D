from klasy import *

def parametry(level):
    if level == 1:      # poziom 1
        # belka(wspolrzedne x i y, nr belki)
        beams = [
            Beam(0, 770, 3), Beam(300, 770, 3), Beam(600, 770, 2),  Beam(700, 560, 4),  Beam(0, 210, 3),
            Beam(400, 560, 3), Beam(280, 560, 2),  Beam(530, 500, 1), Beam(530, 440, 1),
            Beam(530, 100, 1), Beam(850, 210, 3), Beam(1500, 770, 3), Beam(1700, 500, 2), Beam(1900, 300, 2),
            Beam(2200, 200, 3), Beam(2500, 200, 3), Beam(2400, 770, 3), Beam(2700, 770, 3),
            Beam(2300, 500, 3), Beam(2230, 140, 1)
        ]

        # monety(wspolrzedne x i y)
        monety = [Moneta(500, 650), Moneta(100, 100), Moneta(1650, 50),   Moneta(2750, 660), Moneta(2450, 440),
                  ]

        # ghoule(wspolrzedne x i y, zakres poruszania, zdrowie)
        ghoule = [
                  Ghoul(500, 660, 140, 1), Ghoul(2750, 660, 100, 1),
                  Ghoul(100, 100, 150, 1)
                  ]

        # nilfgardczycy(wspolrzedne x i y, kierunek: 1 w prawo, 0 w lewo)
        nilfgardczycy = [Nilfgardczyk(620, 450, 1), Nilfgardczyk(2550, 390, 0), Nilfgardczyk(2500, 90, 0)
                         ]

        # ilosc monet, ktora trzeba uzbierac, aby wygrac
        wynik0 = len(monety)

        pygame.mixer.music.load("soundtrack/Kaer_Morhen.mp3")
        return (beams, monety, ghoule, nilfgardczycy, wynik0)

    if level == 2:      # poziom 2
        # belka(wspolrzedne x i y, nr belki)
        beams = [Beam(0, 770, 9), Beam(300, 560, 8), Beam(360, 500, 5), Beam(360, 440, 5), Beam(300, 380, 5),
                 Beam(300, 320, 5), Beam(300, 260, 5), Beam(700, 200, 7), Beam(700, 770, 7), Beam(1400, 770, 7),
                 Beam(2300, 770, 7), Beam(2100, 770, 7), Beam(2500, 770, 9), Beam(2640, 560, 8), Beam(2640, 360, 5),
                 Beam(2640, 160, 5), Beam(2200, 150, 9), Beam(1600, 420, 6), Beam(1720, 420, 6), Beam(1600, 260, 5),
                 Beam(1800, 100, 5)]

        # monety(wspolrzedne x i y)
        monety = [Moneta(50, 150), Moneta(820, 700), Moneta(2400, 80), Moneta(1700, 370),
                  Moneta(850, 150)
                  ]

        # ghoule(wspolrzedne x i y, zakres poruszania, zdrowie)
        ghoule = [Ghoul(850, 90, 100, 1), Ghoul(1530, 660, 70, 1), Ghoul(1600, 660, 50, 1), Ghoul(1700, 660, 50, 1),
                  Ghoul(2250, 660, 30, 1), Ghoul(2400, 660, 80, 1), Ghoul(2280, 40, 50, 1)
                  ]

        # nilfgardczycy(wspolrzedne x i y, kierunek: 1 w prawo, 0 w lewo)
        nilfgardczycy = [Nilfgardczyk(1000, 660, 0),  Nilfgardczyk(1600, 310, 1), Nilfgardczyk(1600, 150, 1)
                         ]

        # ilosc monet, ktora trzeba uzbierac, aby wygrac
        wynik0 = len(monety)

        pygame.mixer.music.load("soundtrack/velen.mp3")
        return (beams, monety, ghoule, nilfgardczycy, wynik0)


    if level == 3:      # poziom 3
        # belka(wspolrzedne x i y, nr belki)
        beams = [Beam(-200, 770, 12), Beam(600, 770, 12), Beam(200, 600, 10), Beam(300, 400, 10), Beam(400, 200, 10),
                 Beam(600, 600, 10), Beam(600, 110, 12), Beam(900, 770, 12), Beam(900, 110, 11), Beam(900, 400, 11),
                 Beam(900, 600, 11), Beam(1200, 770, 12), Beam(1500, 770, 12), Beam(1600, 600, 10), Beam(1400, 400, 10),
                 Beam(1600, 200, 10), Beam(1800, 100, 10), Beam(2000, 110, 12), Beam(2000, 110, 11),
                 Beam(2000, 400, 11), Beam(2000, 700, 11), Beam(1700, 770, 12), Beam(2300, 110, 12),
                 Beam(2300, 770, 12), Beam(2000, 770, 12), Beam(2600, 770, 12), Beam(2400, 500, 10),
                 Beam(2000, 300, 12), Beam(1940, 400, 10), Beam(1940, 600, 10)
        ]

        # monety(wspolrzedne x i y)
        monety = [Moneta(50, 150), Moneta(1900, 600), Moneta(1300, 50), Moneta(2100, 500), Moneta(750, 660),
                  Moneta(2060, 200)
                  ]

        # ghoule(wspolrzedne x i y, zakres poruszania, zdrowie)
        ghoule = [Ghoul(1530, 660, 70, 18), Ghoul(1600, 660, 70, 18), Ghoul(1700, 660, 50, 18),
                  Ghoul(2250, 660, 30, 18), Ghoul(2400, 660, 80, 18), Ghoul(2100, 0, 30, 1), Ghoul(750, 660, 100, 18)
                  ]

        # nilfgardczycy(wspolrzedne x i y, kierunek: 1 w prawo, 0 w lewo)
        nilfgardczycy = [Nilfgardczyk(900, 0, 0),  Nilfgardczyk(1940, 290, 0), Nilfgardczyk(1940, 490, 0),
                         Nilfgardczyk(2130, 190, 1), Nilfgardczyk(2400, 0, 0)
                         ]

        # ilosc monet, ktora trzeba uzbierac, aby wygrac
        wynik0 = len(monety)

        pygame.mixer.music.load("soundtrack/pobojowisko.mp3")
        return (beams, monety, ghoule, nilfgardczycy, wynik0)
