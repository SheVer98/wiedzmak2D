import pygame
from math import floor

# rozmiar okna
resolution = (1300, 800)
window = pygame.display.set_mode(resolution)


class Przycisk:
    def __init__(self, x_cord, y_cord, file_name):
        self.x_cord = x_cord
        self.y_cord = y_cord
        self.przycisk_image = pygame.image.load(f"{file_name}.png")
        self.najechany_przycisk_image = pygame.image.load(f"{file_name}_najechany.png")
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.przycisk_image.get_width(), self.przycisk_image.get_height())

    def tick(self):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                return True

    def draw(self, window):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            window.blit(self.najechany_przycisk_image, (self.x_cord, self.y_cord))
        else:
            window.blit(self.przycisk_image, (self.x_cord, self.y_cord))

class Background:
    def __init__(self, level):
        self.x_cord = 0
        self.y_cord = 0
        if level == 1:
            self.image = pygame.image.load("background/kaer_morhen.jpg")
        if level == 2:
            self.image = pygame.image.load("background/velen.jpg")
        if level == 3:
            self.image = pygame.image.load("background/pobojowisko.jpg")
        self.width = self.image.get_width()

    def tick(self, player):
        if self.width - resolution[0] / 2 > player.x_cord >= resolution[0] / 2:
            self.x_cord -= player.hor_velocity
        elif player.x_cord >= self.width - resolution[0] / 2:
            self.x_cord = - self.width + resolution[0]
        else:
            self.x_cord = 0

    def draw(self, window):
        window.blit(self.image, (self.x_cord, self.y_cord))

class Physic:       # w tej klase sprawdzane jest zachowanie obiektow wzgledem siebie oraz wzledem tla
    def __init__(self, x, y, width, height, acc, max_vel):
        self.x_cord = x     # wspolrzedna x
        self.y_cord = y     # wspolrzedna y
        self.hor_velocity = 0    # predkosc w poziomie
        self.ver_velocity = 0    # predkosc w poziomie
        self.acc = acc  # przyspieszenie
        self.max_vel = max_vel  # maksymalna predkosc
        self.width = width      # szerokosc
        self.height = height     # wysokosc
        self.previous_x = x     # wspolrzedna x z poprzedniej klatki
        self.previous_y = y     # wspolrzedna y z poprzedniej klatki
        self.jumping = False    # czy postac skacze
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)



    def physic_tick(self, beams, monety, ghoule, walka, kierunek, nilgardczycy, background_width, przegrana):
        self.ver_velocity += 0.5        # predkosc w pionie
        self.x_cord += self.hor_velocity
        self.y_cord += self.ver_velocity
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)    # odswiezanie hitboxa

        for beam in beams:
            if beam.hitbox.colliderect(self.hitbox):     # cofanie obiektu do miejsca z poprzednie klatki
                if (self.x_cord + self.width >= beam.x_cord + 1 > self.previous_x + self.width) and (self.y_cord + self.height > beam.y_cord+1):     # kolizja z prawej strony
                    self.x_cord = self.previous_x
                    self.hor_velocity = 0

                if (self.x_cord <= beam.x_cord + beam.width - 1 < self.previous_x) and (self.y_cord + self.height > beam.y_cord+1):    # kolizja z lewej strony
                    self.x_cord = self.previous_x
                    self.hor_velocity = 0

                if self.y_cord + self.height >= beam.y_cord + 1 > self.previous_y:  # kolizja z dołu
                    self.y_cord = self.previous_y
                    self.ver_velocity = 0
                    self.jumping = False    # skok moze byc wykonany tylko gdy jumping jest falszywe

                if self.y_cord <= beam.y_cord + beam.height - 1 < self.previous_y:   # kolizja z gory
                    self.y_cord = self.previous_y
                    self.ver_velocity = 0



        for moneta in monety:
            if moneta.hitbox.colliderect(self.hitbox):
                monety.remove(moneta)
                coin = pygame.mixer.Sound("soundtrack/moneta.mp3")
                coin.set_volume(0.5)
                pygame.mixer.Sound.play(coin)

        # sprawdzania czy przeciwnicy znajduja sie w zakresie ataku postaci, po nacisnieciu klawisza ataku
        if walka == 1:
            if kierunek == 1:
                self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width + 70, self.height)
            elif kierunek == 0:
                self.hitbox = pygame.Rect(self.x_cord - 70, self.y_cord, self.width, self.height)
            for ghoul in ghoule:
                if ghoul.hitbox.colliderect(self.hitbox):
                    if ghoul.zdrowie == 18 or ghoul.zdrowie == 1:
                        miecz = pygame.mixer.Sound("soundtrack/trafienie.mp3")
                        miecz.set_volume(0.2)
                        pygame.mixer.Sound.play(miecz)
                    ghoul.zdrowie -= 1
                    if ghoul.zdrowie == 0:
                        ghoule.remove(ghoul)

            for nilgardczyk in nilgardczycy:
                if nilgardczyk.hitbox.colliderect(self.hitbox):
                    nilgardczycy.remove(nilgardczyk)
                    miecz = pygame.mixer.Sound("soundtrack/trafienie2.mp3")
                    miecz.set_volume(0.2)
                    pygame.mixer.Sound.play(miecz)
        else:
            for ghoul in ghoule:
                if ghoul.hitbox.colliderect(self.hitbox):
                    przegrana = 1



        # ustanowienie granic mapy
        if self.x_cord <= 0:
            self.x_cord = 0
        if self.x_cord >= (background_width - 50):
            self.x_cord = background_width - 50
        if self.y_cord >= 800:
            przegrana = 1

        # aktualizacja poprzednich wspolrzednych
        self.previous_x = self.x_cord
        self.previous_y = self.y_cord

        return przegrana



class Geralt(Physic):  # opisuje gracza, dziedziczenie klasy Physic
    def __init__(self):
        self.bezruch_prawo_img = pygame.image.load("Geralt/bezruch.png")
        self.bezruch_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/bezruch.png"), True, False)
        width = self.bezruch_prawo_img.get_width()       # szerokosc
        height = self.bezruch_prawo_img.get_height()     # wysokosc
        self.skok_prawo_img = pygame.image.load("Geralt/skok.png")
        self.skok_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/skok.png"), True, False)
        self.krok1_prawo_img = pygame.image.load("Geralt/ruch/krok1.png")
        self.krok1_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/ruch/krok1.png"), True, False)
        self.krok2_prawo_img = pygame.image.load("Geralt/ruch/krok2.png")
        self.krok2_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/ruch/krok2.png"), True, False)
        self.krok3_prawo_img = pygame.image.load("Geralt/ruch/krok3.png")
        self.krok3_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/ruch/krok3.png"), True, False)
        self.walka1_prawo_img = pygame.image.load("Geralt/walka/walka1.png")
        self.walka1_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/walka/walka1.png"), True, False)
        self.walka2_prawo_img = pygame.image.load("Geralt/walka/walka2.png")
        self.walka2_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/walka/walka2.png"), True, False)
        self.walka3_prawo_img = pygame.image.load("Geralt/walka/walka3.png")
        self.walka3_lewo_img = pygame.transform.flip(pygame.image.load("Geralt/walka/walka3.png"), True, False)
        self.ruch_index = 1     # zmienna mowiaca ktora klatka animacji jest narysowana
        self.direction = 1
        self.walka = 0
        self.walka_index = 0
        super().__init__(0, 500, width, height, 0.5, 5)

    def tick(self, keys, beams, monety, ghoule, nilfgardczycy, background_width, przegrana):     # wykonuje sie raz na powtorzeniu petli
        if keys[pygame.K_a] and self.hor_velocity > self.max_vel * -1:
            self.hor_velocity -= self.acc
        if keys[pygame.K_d] and self.hor_velocity < self.max_vel:
            self.hor_velocity += self.acc
        if keys[pygame.K_SPACE] and self.jumping is False:
            self.ver_velocity -= 15
            self.jumping = True
        if self.hor_velocity > 0:
            self.direction = 1
        elif self.hor_velocity < 0:
            self.direction = 0
        if not (keys[pygame.K_d] or keys[pygame.K_a]):
            if self.hor_velocity > 0:
                self.hor_velocity -= self.acc
            elif self.hor_velocity < 0:
                self.hor_velocity += self.acc

        if keys[pygame.K_RCTRL]:
            self.walka = 1
            miecz = pygame.mixer.Sound("soundtrack/miecz.mp3")
            miecz.set_volume(0.2)
            pygame.mixer.Sound.play(miecz)

        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)
        przegrana = self.physic_tick(beams, monety, ghoule, self.walka, self.direction, nilfgardczycy, background_width, przegrana)
        return (self.hitbox, przegrana)



    def draw(self, win, background_width):
        if background_width - resolution[0] / 2 > self.x_cord >= resolution[0] / 2:
            x_screen = resolution[0] / 2
        elif self.x_cord >= background_width - resolution[0] / 2:
            x_screen = self.x_cord - background_width + resolution[0]
        else:
            x_screen = self.x_cord

        if self.walka == 1:
            if self.direction == 1:
                self.walka_index += 0.2
                if floor(self.walka_index) == 0:
                    win.blit(self.walka1_prawo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) == 1:
                    win.blit(self.walka2_prawo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) == 2:
                    win.blit(self.walka3_prawo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) >= 3:
                    win.blit(self.bezruch_prawo_img, (x_screen, self.y_cord))
                    self.walka_index = 0
                    self.walka = 0
            elif self.direction == 0:
                self.walka_index += 0.2
                if floor(self.walka_index) == 0:
                    win.blit(self.walka1_lewo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) == 1:
                    win.blit(self.walka2_lewo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) == 2:
                    win.blit(self.walka3_lewo_img, (x_screen, self.y_cord))
                elif floor(self.walka_index) >= 3:
                    win.blit(self.bezruch_lewo_img, (x_screen, self.y_cord))
                    self.walka_index = 0
                    self.walka = 0


        else:
            if self.jumping:
                if self.direction == 0:
                    win.blit(self.skok_lewo_img, (x_screen, self.y_cord))
                elif self.direction == 1:
                    win.blit(self.skok_prawo_img, (x_screen, self.y_cord))
            elif self.hor_velocity != 0:
                if self.direction == 0:
                    if floor(self.ruch_index) == 1:
                        win.blit(self.krok1_lewo_img, (x_screen, self.y_cord))
                    elif floor(self.ruch_index) == 2:
                        win.blit(self.krok2_lewo_img, (x_screen, self.y_cord))
                    elif floor(self.ruch_index) == 3:
                        win.blit(self.krok3_lewo_img, (x_screen, self.y_cord))
                elif self.direction == 1:
                    if floor(self.ruch_index) == 1:
                        win.blit(self.krok1_prawo_img, (x_screen, self.y_cord))
                    elif floor(self.ruch_index) == 2:
                        win.blit(self.krok2_prawo_img, (x_screen, self.y_cord))
                    elif floor(self.ruch_index) == 3:
                        win.blit(self.krok3_prawo_img, (x_screen, self.y_cord))

                self.ruch_index += 0.1
                if self.ruch_index > 4:
                    self.ruch_index = 1
            else:
                if self.direction == 0:
                    win.blit(self.bezruch_lewo_img, (x_screen, self.y_cord))
                elif self.direction == 1:
                    win.blit(self.bezruch_prawo_img, (x_screen, self.y_cord))




class Moneta():
    def __init__(self, x, y):
        self.moneta_img = pygame.image.load("Geralt/moneta.png")
        self.x_cord = x
        self.y_cord = y
        self.width = self.moneta_img.get_width()      # szerokosc
        self.height = self.moneta_img.get_height()     # wysokosc
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)


    def draw(self, background_x):
            window.blit(self.moneta_img, (self.x_cord + background_x, self.y_cord))


class Beam:     # belka
    def __init__(self, x, y, numer):
        self.belka_img = pygame.image.load(f"belki/{numer}.jpg")
        self.x_cord = x
        self.y_cord = y
        self.width = self.belka_img.get_width()      # szerokosc
        self.height = self.belka_img.get_height()     # wysokosc
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)

    def draw(self, window, background_x):
        window.blit(self.belka_img, (self.x_cord + background_x, self.y_cord))


class Ghoul():
    def __init__(self, x, y, zasieg, zdrowie):
        self.krok1_prawo_img = pygame.image.load("ghoul/ghoul1.png")
        self.krok1_lewo_img = pygame.transform.flip(pygame.image.load("ghoul/ghoul1.png"), True, False)
        self.x_cord = x     # wspolrzedna x
        self.y_cord = y     # wspolrzedna y
        self.width = self.krok1_prawo_img.get_width()      # szerokosc
        self.height = self.krok1_prawo_img.get_height()     # wysokosc
        self.krok2_prawo_img = pygame.image.load("ghoul/ghoul2.png")
        self.krok2_lewo_img = pygame.transform.flip(pygame.image.load("ghoul/ghoul2.png"), True, False)
        self.krok3_prawo_img = pygame.image.load("ghoul/ghoul3.png")
        self.krok3_lewo_img = pygame.transform.flip(pygame.image.load("ghoul/ghoul3.png"), True, False)
        self.direction = 1
        self.x1 = x
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)
        self.ruch_index = 1
        self.zasieg = zasieg
        self.zdrowie = zdrowie


    def tick(self):
        if self.x_cord >= (self.x1 + self.zasieg):
            self.direction = -1
        if self.x_cord <= (self.x1 - self.zasieg):
            self.direction = 1
        self.x_cord += 4 * self.direction
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)


    def draw(self, background_x):
        if self.direction == -1:
            if floor(self.ruch_index) == 1:
                window.blit(self.krok1_lewo_img, (self.x_cord + background_x, self.y_cord))
            elif floor(self.ruch_index) == 2:
                window.blit(self.krok2_lewo_img, (self.x_cord + background_x, self.y_cord))
            elif floor(self.ruch_index) == 3:
                window.blit(self.krok3_lewo_img, (self.x_cord + background_x, self.y_cord))
        elif self.direction == 1:
            if floor(self.ruch_index) == 1:
                window.blit(self.krok1_prawo_img, (self.x_cord + background_x, self.y_cord))
            elif floor(self.ruch_index) == 2:
                window.blit(self.krok2_prawo_img, (self.x_cord + background_x, self.y_cord))
            elif floor(self.ruch_index) == 3:
                window.blit(self.krok3_prawo_img, (self.x_cord + background_x, self.y_cord))

        self.ruch_index += 0.2
        if self.ruch_index > 4:
            self.ruch_index = 1

class Nilfgardczyk():
    def __init__(self, x, y, z):
        self.bezruch_prawo_img = pygame.image.load("nilfgardczyk/nilfgardczyk1.png")
        self.bezruch_lewo_img = pygame.transform.flip(pygame.image.load("nilfgardczyk/nilfgardczyk1.png"), True, False)
        self.x_cord = x     # wspolrzedna x
        self.y_cord = y     # wspolrzedna y
        self.width = self.bezruch_prawo_img.get_width()      # szerokosc
        self.height = self.bezruch_prawo_img.get_height()     # wysokosc
        self.pozycja_prawo_img = pygame.image.load("nilfgardczyk/nilfgardczyk2.png")
        self.pozycja_lewo_img = pygame.transform.flip(pygame.image.load("nilfgardczyk/nilfgardczyk2.png"), True, False)
        self.direction = z
        self.ruch_index = 0
        self.strzaly = []
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)
        self.hitbox2 = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)
        self.czekaj = 1

    def tick(self, polozenie, beams):
        for strzala in self.strzaly:
            (self.hitbox2, x_strzaly) = strzala.tick()
            if self.hitbox2.colliderect(polozenie):
                przegrana = 1
                self.strzaly.remove(strzala)
                return przegrana
            for beam in beams:
                if beam.hitbox.colliderect(self.hitbox2):
                    self.strzaly.remove(strzala)
            if x_strzaly <= self.x_cord - 800 or x_strzaly >= self.x_cord+800:
                self.strzaly.remove(strzala)




    def draw(self, background_x):
            if self.direction == 1:  # prawo
                if floor(self.ruch_index) <= 5:
                    window.blit(self.bezruch_prawo_img, (self.x_cord + background_x, self.y_cord))
                elif floor(self.ruch_index) <= 7 and self.ruch_index > 5:
                    window.blit(self.pozycja_prawo_img, (self.x_cord + background_x, self.y_cord))
                    if self.ruch_index >= 6 and self.czekaj == 0:
                        self.strzaly.append(Strzala(self.x_cord, self.y_cord, self.width, self.height, self.direction))
                        self.czekaj = 1
            elif self.direction == 0:    # lewo
                if floor(self.ruch_index) <= 5:
                    window.blit(self.bezruch_lewo_img, (self.x_cord + background_x, self.y_cord))
                elif floor(self.ruch_index) <= 7 and self.ruch_index > 5:
                    window.blit(self.pozycja_lewo_img, (self.x_cord + background_x, self.y_cord))
                    if self.ruch_index >= 6 and self.czekaj == 0:
                        self.strzaly.append(Strzala(self.x_cord, self.y_cord, self.width, self.height, self.direction))
                        self.czekaj = 1

            self.ruch_index += 0.06     # czestotliwosc strzalu z luku
            if self.ruch_index > 7:
                self.ruch_index = 0
                self.czekaj = 0
            for strzala in self.strzaly:
                strzala.draw(background_x)

class Strzala():
    def __init__(self, x, y, width, height, z):
        self.direction = z
        self.strzala_prawo_img = pygame.image.load("nilfgardczyk/strzala.png")
        self.strzala_lewo_img = pygame.transform.flip(pygame.image.load("nilfgardczyk/strzala.png"), True, False)
        self.width = self.strzala_prawo_img.get_width()  # szerokosc
        self.height = self.strzala_prawo_img.get_height()  # wysokosc
        if self.direction == 1:
            self.x_cord = x + width  # wspolrzedna x
            self.y_cord = y + height/2  # wspolrzedna y
        if self.direction == 0:
            self.x_cord = x - self.width  # wspolrzedna x
            self.y_cord = y + height/2  # wspolrzedna y
        self.hitbox = pygame.Rect(self.x_cord, self.y_cord, self.width, self.height)
        self.hor_velocity = 5

    def tick(self):
        if self.direction == 0:     # lewo
            self.x_cord -= self.hor_velocity
        if self.direction == 1:     # prawo
            self.x_cord += self.hor_velocity
        return (pygame.Rect(self.x_cord, self.y_cord, self.width, self.height), self.x_cord)


    def draw(self, background_x):
        if self.direction == 0:     # lewo
            window.blit(self.strzala_lewo_img, (self.x_cord + background_x, self.y_cord))
        if self.direction == 1:     # prawo
            window.blit(self.strzala_prawo_img, (self.x_cord + background_x, self.y_cord))



def porazka():
    clock = 0
    pygame.mixer.music.stop()
    przegrana = pygame.mixer.Sound("soundtrack/przegrana.mp3")
    przegrana.set_volume(0.2)
    pygame.mixer.Sound.play(przegrana)
    while clock < 2:
        clock += pygame.time.Clock().tick(60) / 1000
        przegrana_image = pygame.font.Font.render(pygame.font.SysFont("calisto", 150), f"PORAZKA", True, (89, 19, 8))
        window.blit(przegrana_image, (240, 260))
        pygame.display.update()

def zwyciestwo():
    clock = 0
    pygame.mixer.music.stop()
    wygrana = pygame.mixer.Sound("soundtrack/wygrana.mp3")
    wygrana.set_volume(0.2)
    pygame.mixer.Sound.play(wygrana)
    while clock < 2:
        clock += pygame.time.Clock().tick(60) / 1000
        przegrana_image = pygame.font.Font.render(pygame.font.SysFont("bodoni", 150), f"ZWYCIESTWO", True, (7, 43, 15))
        window.blit(przegrana_image, (170, 250))
        pygame.display.update()
